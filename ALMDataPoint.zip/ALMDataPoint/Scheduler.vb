Set qtApp=CreateObject("QuickTest.Application")

Set qtResultOpt=CreateObject("QuickTest.RunResultsOptions")

qtResult.ResultsLocation="C:\ALMDataPoint\Results"

qtApp.Launch

qtApp.Visible=True

qtApp.Open "C:\ALMDataPointTestExecutionProgress",True

Set objTest=qtApp.Test

objTest.Run qtResultOpt